STRING_FEATURE = ['Title', 'Description']
FLOAT_FEATURE = ['IMDb Rating', 'My Rate']
