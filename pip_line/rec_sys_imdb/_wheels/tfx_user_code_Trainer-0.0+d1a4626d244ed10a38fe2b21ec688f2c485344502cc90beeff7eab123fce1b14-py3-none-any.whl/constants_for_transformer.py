FLOAT_FEATURE = ['IMDb Rating'] # I will keep 'My Rate' as it should be the Y label
