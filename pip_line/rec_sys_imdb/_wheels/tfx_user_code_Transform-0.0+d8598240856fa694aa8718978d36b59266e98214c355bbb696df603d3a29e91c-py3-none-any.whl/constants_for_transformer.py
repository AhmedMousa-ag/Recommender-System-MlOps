STRING_FEATURE = ['Description']
FLOAT_FEATURE = ['IMDb Rating', 'My Rate']
