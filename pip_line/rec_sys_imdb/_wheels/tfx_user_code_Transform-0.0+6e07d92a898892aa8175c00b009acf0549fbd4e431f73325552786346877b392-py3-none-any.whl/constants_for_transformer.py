STRING_FEATURE = ['Description']
FLOAT_FEATURE = ['IMDb_Rating', 'My Rate']
LABEL = 'My Rate'
