FLOAT_FEATURE = ['IMDb Rating','My Rate'] # I will keep 'My Rate' as it should be the Y label
