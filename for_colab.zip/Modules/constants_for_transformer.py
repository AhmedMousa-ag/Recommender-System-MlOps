FLOAT_FEATURE = ['IMDb Rating', 'My Rate']
